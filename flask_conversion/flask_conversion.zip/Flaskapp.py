from flask import Flask
import os

app = Flask(__name__, static_folder='images', static_url_path='/images')

@app.route('/')
def home():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>My Personal Website</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			margin: 0;
			padding: 0;
			background: #f4f4f9;
			color: #222;
		}
		header {
			background: #222;
			color: #fff;
			padding: 2rem 0 1rem 0;
			text-align: center;
		}
		nav {
			margin: 1rem 0;
		}
		nav a {
			color: #fff;
			text-decoration: none;
			margin: 0 1.5rem;
			font-weight: 500;
			transition: color 0.2s;
		}
		nav a:hover {
			color: #ff9800;
		}
		.container {
			max-width: 900px;
			margin: 2rem auto;
			background: #fff;
			border-radius: 10px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.07);
			padding: 2rem 2.5rem;
		}
		h1 {
			margin-bottom: 0.5rem;
		}
		.intro {
			font-size: 1.2rem;
			margin-bottom: 2rem;
		}
		.cta {
			display: inline-block;
			margin-top: 1.5rem;
			padding: 0.7rem 2rem;
			background: #ff9800;
			color: #fff;
			border-radius: 5px;
			text-decoration: none;
			font-weight: bold;
			transition: background 0.2s;
		}
		.cta:hover {
			background: #e65100;
		}
		@media (max-width: 600px) {
			.container {
				padding: 1rem;
			}
			nav a {
				margin: 0 0.5rem;
			}
		}
	</style>
</head>
<body>
	<header>
		<h1>Welcome to My Personal Website</h1>
		<nav>
			<a href="/">Home</a>
			<a href="/about">About</a>
			<a href="/projects">Projects</a>
			<a href="/resume">Resume</a>
			<a href="/contact">Contact</a>
		</nav>
	</header>
	<div class="container">
		<div class="intro">
			<p>Hello! I'm <strong>Reid Zona</strong>, a Master of Science in Information Systems student at Indiana University's Kelley School of Business. I have a passion for data-driven solutions, digital transformation, and bridging the gap between technology and business. Explore my site to learn about my education, experience, projects, and how to connect with me.</p>
		</div>
		<a class="cta" href="/about">Learn more about me</a>
	</div>
</body>
</html>
    '''

@app.route('/about')
def about():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>About Me - My Personal Website</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			margin: 0;
			padding: 0;
			background: #f4f4f9;
			color: #222;
		}
		header {
			background: #222;
			color: #fff;
			padding: 2rem 0 1rem 0;
			text-align: center;
		}
		nav {
			margin: 1rem 0;
		}
		nav a {
			color: #fff;
			text-decoration: none;
			margin: 0 1.5rem;
			font-weight: 500;
			transition: color 0.2s;
		}
		nav a:hover {
			color: #ff9800;
		}
		.container {
			max-width: 900px;
			margin: 2rem auto;
			background: #fff;
			border-radius: 10px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.07);
			padding: 2rem 2.5rem;
		}
		h1 {
			margin-bottom: 0.5rem;
		}
		.about-section {
			font-size: 1.1rem;
			line-height: 1.7;
		}
		.profile-pic {
			float: right;
			margin-left: 2rem;
			width: 160px;
			height: 160px;
			object-fit: contain;
			background: #fff;
			border-radius: 50%;
			box-shadow: 0 2px 8px rgba(0,0,0,0.10);
			border: 2px solid #eee;
		}
		@media (max-width: 600px) {
			.container {
				padding: 1rem;
			}
			nav a {
				margin: 0 0.5rem;
			}
			.profile-pic {
				float: none;
				display: block;
				margin: 0 auto 1.5rem auto;
			}
		}
	</style>
</head>
<body>
	<header>
		<h1>About Me</h1>
		<nav>
			<a href="/">Home</a>
			<a href="/about">About</a>
			<a href="/projects">Projects</a>
			<a href="/resume">Resume</a>
			<a href="/contact">Contact</a>
		</nav>
	</header>
	<div class="container">
	<img src="/images/MSIS_Headshot.png" alt="Reid Zona headshot" class="profile-pic" onerror="this.onerror=null;this.src='https://ui-avatars.com/api/?name=Reid+Zona&background=0D8ABC&color=fff&size=160';">
		<div class="about-section">
			<h2>Hello, I'm Reid Zona</h2>
			<p>
				I am currently pursuing my Master of Science in Information Systems at Indiana University's Kelley School of Business (expected May 2026). I also hold a Bachelor of Informatics with minors in Business and Psychology from Indiana University's Luddy School of Informatics, Computing & Engineering.<br><br>
				My academic journey has been complemented by hands-on experience in analytics, business strategy, and technology consulting. As a Summer Analyst at Insight2Profit, I analyzed over 10 million transactions in Power BI to create a dynamic pricing tool, projected to impact $1.7 million in revenue. I also developed a tier-based sales incentive framework and implemented revenue recognition practices, uncovering $2 million in new revenue.<br><br>
				Previously, as a Strategic Operations Intern at Republic Airways, I engineered predictive models and dashboards to provide insights into pilot attrition and fuel consumption for a regional airline. My work supported data-driven decision making and operational governance.<br><br>
				I have international experience as a Business Analyst Intern at Tribboo in Barcelona, where I refined industry analysis and mapped strategic positioning for a software start-up. My leadership roles include serving as Director of Corporate Relations for the MSIS Student Association and as a Student Ambassador for the Luddy School.<br><br>
				My technical skills include Python, SQL, R, Power BI, Tableau, Java, CSS, HTML, and more. I am passionate about leveraging technology to solve business problems and am always eager to learn and collaborate.
			</p>
		</div>
	</div>
</body>
</html>
    '''

@app.route('/projects')
def projects():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Projects - My Personal Website</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			margin: 0;
			padding: 0;
			background: #f4f4f9;
			color: #222;
		}
		header {
			background: #222;
			color: #fff;
			padding: 2rem 0 1rem 0;
			text-align: center;
		}
		nav {
			margin: 1rem 0;
		}
		nav a {
			color: #fff;
			text-decoration: none;
			margin: 0 1.5rem;
			font-weight: 500;
			transition: color 0.2s;
		}
		nav a:hover {
			color: #ff9800;
		}
		.container {
			max-width: 900px;
			margin: 2rem auto;
			background: #fff;
			border-radius: 10px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.07);
			padding: 2rem 2.5rem;
		}
		h1 {
			margin-bottom: 0.5rem;
		}
		.project {
			padding: 2rem;
			margin-bottom: 2rem;
			background: #fafafa;
			border-radius: 8px;
			box-shadow: 0 1px 3px rgba(0,0,0,0.1);
		}
		.project-title {
			color: #222;
			margin-bottom: 1rem;
			font-size: 1.4rem;
		}
		.project-desc {
			color: #444;
			line-height: 1.6;
		}
		.project-highlights {
			margin-top: 1rem;
			padding-left: 1.2rem;
		}
		.project-highlights li {
			margin-bottom: 0.5rem;
			color: #555;
		}
		.github-link {
			display: inline-block;
			margin-top: 1rem;
			padding: 0.5rem 1rem;
			background: #24292e;
			color: #fff;
			text-decoration: none;
			border-radius: 4px;
			font-size: 0.9rem;
			transition: background 0.2s;
		}
		.github-link:hover {
			background: #2f363d;
		}
		@media (max-width: 600px) {
			.container {
				padding: 1rem;
			}
			nav a {
				margin: 0 0.5rem;
			}
		}
	</style>
</head>
<body>
	<header>
		<h1>My Projects</h1>
		<nav>
			<a href="/">Home</a>
			<a href="/about">About</a>
			<a href="/projects">Projects</a>
			<a href="/resume">Resume</a>
			<a href="/contact">Contact</a>
		</nav>
	</header>
	<div class="container">
			<div class="project">
				<h2 class="project-title">Dynamic Pricing Recommendation Tool at Insight2Profit</h2>
				<p class="project-desc">
					Developed a sophisticated pricing analytics solution that transformed transaction data into actionable pricing strategies, resulting in significant revenue impact for the business.
				</p>
				<ul class="project-highlights">
					<li>Analyzed and processed over 10 million transactions using Power BI to create comprehensive pricing insights.</li>
					<li>Designed and implemented a dynamic pricing recommendation tool that standardized discount strategies.</li>
					<li>Generated projected revenue impact of $1.7 million through optimized pricing strategies.</li>
					<li>Established robust data mapping and validation practices for ERP implementations.</li>
					<li>Created detailed documentation and training materials for stakeholder adoption.</li>
				</ul>
			</div>
			
			<div class="project">
				<h2 class="project-title">Predictive Analytics & Dashboards for Republic Airways</h2>
				<p class="project-desc">
					Led development of sophisticated data analytics solutions for a major regional airline operating 200+ aircraft and 900+ daily flights. Created predictive models and interactive dashboards that revolutionized operational decision-making processes.
				</p>
				<ul class="project-highlights">
					<li>Engineered predictive models for pilot attrition and fuel consumption analysis using Python and advanced analytics.</li>
					<li>Developed 5 interactive Power BI dashboards tracking key operational metrics and KPIs.</li>
					<li>Implemented automated data pipelines that significantly improved reporting efficiency.</li>
					<li>Provided actionable insights that directly influenced strategic operational decisions.</li>
				</ul>
			</div>
			
			<div class="project">
				<h2 class="project-title">Personal Portfolio Website</h2>
				<p class="project-desc">
					Designed and developed a modern, responsive personal portfolio website using Flask and contemporary web technologies. Built to showcase professional experience and technical capabilities while demonstrating clean code practices and web development skills.
				</p>
				<ul class="project-highlights">
					<li>Built with Flask framework for robust backend functionality and efficient routing</li>
					<li>Implemented responsive design using modern CSS techniques for optimal viewing across devices</li>
					<li>Created modular HTML templates for consistent styling and maintainable code</li>
					<li>Deployed with proper configuration for secure and reliable hosting</li>
				</ul>
				<a href="https://github.com/rzona-msis/website" class="github-link" target="_blank">View on GitHub ↗</a>
			</div>
	</div>
</body>
</html>
    '''

@app.route('/resume')
def resume():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Resume - Reid Zona</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			margin: 0;
			padding: 0;
			background: #f4f4f9;
			color: #222;
		}
		header {
			background: #222;
			color: #fff;
			padding: 2rem 0 1rem 0;
			text-align: center;
		}
		nav {
			margin: 1rem 0;
		}
		nav a {
			color: #fff;
			text-decoration: none;
			margin: 0 1.5rem;
			font-weight: 500;
			transition: color 0.2s;
		}
		nav a:hover {
			color: #ff9800;
		}
		.container {
			max-width: 900px;
			margin: 2rem auto;
			background: #fff;
			border-radius: 10px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.07);
			padding: 2rem 2.5rem;
		}
		h1 {
			margin-bottom: 0.5rem;
		}
		.section-title {
			color: #ff9800;
			margin-top: 2rem;
			margin-bottom: 0.5rem;
			font-size: 1.2rem;
			font-weight: bold;
		}
		.pdf-viewer {
			width: 100%;
			height: 700px;
			border: none;
			border-radius: 8px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.10);
			margin-top: 2rem;
		}
		.download-link {
			display: inline-block;
			margin-top: 1rem;
			padding: 0.6rem 1.5rem;
			background: #ff9800;
			color: #fff;
			border-radius: 5px;
			text-decoration: none;
			font-weight: bold;
			transition: background 0.2s;
		}
		.download-link:hover {
			background: #e65100;
		}
		ul {
			margin: 0.5rem 0 1.5rem 1.5rem;
		}
		@media (max-width: 600px) {
			.container {
				padding: 1rem;
			}
			nav a {
				margin: 0 0.5rem;
			}
			.pdf-viewer {
				height: 400px;
			}
		}
	</style>
</head>
<body>
	<header>
		<h1>Reid Zona - Resume</h1>
		<nav>
			<a href="/">Home</a>
			<a href="/about">About</a>
			<a href="/projects">Projects</a>
			<a href="/resume">Resume</a>
			<a href="/contact">Contact</a>
		</nav>
	</header>
	<div class="container">
		<h2 class="section-title">Contact Information</h2>
		<ul>
			<li><strong>Name:</strong> Reid Zona</li>
			<li><strong>Email:</strong> reidzona@gmail.com</li>
			<li><strong>Phone:</strong> (480) 678-9642</li>
			<li><strong>Location:</strong> Chandler, AZ</li>
			<li><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/reidzona" target="_blank">linkedin.com/in/reidzona</a></li>
		</ul>

		<h2 class="section-title">Education</h2>
		<ul>
			<li><strong>Arizona State University</strong> — B.S. Computer Science (Expected May 2025)</li>
			<li><strong>GPA:</strong> 3.97</li>
		</ul>

		<h2 class="section-title">Technical Skills</h2>
		<ul>
			<li>Languages: Python, Java, C, C++, JavaScript, SQL, HTML, CSS</li>
			<li>Frameworks/Tools: Flask, React, Node.js, Git, Linux, Docker, AWS</li>
			<li>Other: Agile, REST APIs, OOP, Data Structures, Algorithms</li>
		</ul>

		<h2 class="section-title">Experience</h2>
		<ul>
			<li><strong>Software Engineering Intern</strong> — Honeywell (May 2024 - Aug 2024)<br>
				• Developed Python automation tools for cloud infrastructure.<br>
				• Improved CI/CD pipelines and reduced deployment time by 30%.
			</li>
			<li><strong>Undergraduate Researcher</strong> — ASU (Jan 2023 - Present)<br>
				• Built web apps for data visualization using Flask and React.<br>
				• Published research on machine learning model interpretability.
			</li>
		</ul>

		<h2 class="section-title">Projects</h2>
		<ul>
			<li><strong>Personal Portfolio Website:</strong> Designed and deployed a responsive website using Flask and React to showcase projects and skills.</li>
			<li><strong>Smart Home Automation:</strong> Created a Python-based IoT system for home device control and monitoring.</li>
		</ul>

		<h2 class="section-title">Honors & Awards</h2>
		<ul>
			<li>Dean's List, ASU (2021-2025)</li>
			<li>National Merit Scholar</li>
		</ul>

		<h2 class="section-title">Download or View PDF</h2>
		<p>You can view my full resume below or <a class="download-link" href="resume.pdf" download>download the PDF</a>.</p>
		<iframe class="pdf-viewer" src="resume.pdf" title="Reid Zona Resume PDF"></iframe>
	</div>
</body>
</html>
    '''

@app.route('/contact')
def contact():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact - My Personal Website</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			margin: 0;
			padding: 0;
			background: #f4f4f9;
			color: #222;
		}
		header {
			background: #222;
			color: #fff;
			padding: 2rem 0 1rem 0;
			text-align: center;
		}
		nav {
			margin: 1rem 0;
		}
		nav a {
			color: #fff;
			text-decoration: none;
			margin: 0 1.5rem;
			font-weight: 500;
			transition: color 0.2s;
		}
		nav a:hover {
			color: #ff9800;
		}
		.container {
			max-width: 500px;
			margin: 2rem auto;
			background: #fff;
			border-radius: 10px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.07);
			padding: 2rem 2.5rem;
		}
		h1 {
			margin-bottom: 0.5rem;
		}
		form {
			display: flex;
			flex-direction: column;
			gap: 1.2rem;
		}
		label {
			font-weight: 500;
			margin-bottom: 0.3rem;
		}
		input[type="text"],
		input[type="email"],
		input[type="password"] {
			padding: 0.7rem;
			border: 1px solid #ccc;
			border-radius: 5px;
			font-size: 1rem;
		}
		.error-message {
			color: #d32f2f;
			font-size: 0.98rem;
			margin-top: -0.8rem;
			margin-bottom: 0.5rem;
		}
		button[type="submit"] {
			background: #ff9800;
			color: #fff;
			border: none;
			border-radius: 5px;
			padding: 0.8rem 0;
			font-size: 1.1rem;
			font-weight: bold;
			cursor: pointer;
			transition: background 0.2s;
		}
		button[type="submit"]:hover {
			background: #e65100;
		}
		@media (max-width: 600px) {
			.container {
				padding: 1rem;
			}
			nav a {
				margin: 0 0.5rem;
			}
		}
	</style>
	<script>
	function validateForm(event) {
		let valid = true;
		// Clear previous errors
		document.querySelectorAll('.error-message').forEach(e => e.textContent = '');
		// Get form values
		const firstName = document.getElementById('firstName').value.trim();
		const lastName = document.getElementById('lastName').value.trim();
		const email = document.getElementById('email').value.trim();
		const password = document.getElementById('password').value;
		const confirmPassword = document.getElementById('confirmPassword').value;
		// Validate First Name
		if (!firstName) {
			document.getElementById('firstNameError').textContent = 'First Name is required.';
			valid = false;
		}
		// Validate Last Name
		if (!lastName) {
			document.getElementById('lastNameError').textContent = 'Last Name is required.';
			valid = false;
		}
		// Validate Email
		const emailPattern = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
		if (!email) {
			document.getElementById('emailError').textContent = 'Email Address is required.';
			valid = false;
		} else if (!emailPattern.test(email)) {
			document.getElementById('emailError').textContent = 'Please enter a valid email address.';
			valid = false;
		}
		// Validate Password
		if (!password) {
			document.getElementById('passwordError').textContent = 'Password is required.';
			valid = false;
		} else if (password.length < 8) {
			document.getElementById('passwordError').textContent = 'Password must be at least 8 characters.';
			valid = false;
		}
		// Validate Confirm Password
		if (!confirmPassword) {
			document.getElementById('confirmPasswordError').textContent = 'Please confirm your password.';
			valid = false;
		} else if (password !== confirmPassword) {
			document.getElementById('confirmPasswordError').textContent = 'Passwords do not match.';
			valid = false;
		}
		if (!valid) {
			event.preventDefault();
		} else {
			// Redirect to thank you page
			event.preventDefault();
			window.location.href = '/thankyou';
		}
	}
	</script>
</head>
<body>
	<header>
		<h1>Contact Me</h1>
		<nav>
			<a href="/">Home</a>
			<a href="/about">About</a>
			<a href="/projects">Projects</a>
			<a href="/resume">Resume</a>
			<a href="/contact">Contact</a>
		</nav>
	</header>
	<div class="container">
	<p>Thank you for your interest! Please fill out the form below to get in touch. Whether you have a question about my experience at Indiana University, my analytics and consulting work, or want to connect about opportunities, I look forward to hearing from you.</p>
		<form id="contactForm" onsubmit="validateForm(event)" novalidate>
			<div>
				<label for="firstName">First Name<span style="color:#d32f2f">*</span></label>
				<input type="text" id="firstName" name="firstName" required>
				<div id="firstNameError" class="error-message"></div>
			</div>
			<div>
				<label for="lastName">Last Name<span style="color:#d32f2f">*</span></label>
				<input type="text" id="lastName" name="lastName" required>
				<div id="lastNameError" class="error-message"></div>
			</div>
			<div>
				<label for="email">Email Address<span style="color:#d32f2f">*</span></label>
				<input type="email" id="email" name="email" required pattern="^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$">
				<div id="emailError" class="error-message"></div>
			</div>
			<div>
				<label for="password">Password<span style="color:#d32f2f">*</span></label>
				<input type="password" id="password" name="password" required minlength="8">
				<div id="passwordError" class="error-message"></div>
			</div>
			<div>
				<label for="confirmPassword">Confirm Password<span style="color:#d32f2f">*</span></label>
				<input type="password" id="confirmPassword" name="confirmPassword" required minlength="8">
				<div id="confirmPasswordError" class="error-message"></div>
			</div>
			<button type="submit">Submit</button>
		</form>
	</div>
</body>
</html>
    '''

@app.route('/thankyou')
def thankyou():
    return '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You - My Personal Website</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f9;
            color: #222;
        }
        header {
            background: #222;
            color: #fff;
            padding: 2rem 0 1rem 0;
            text-align: center;
        }
        nav {
            margin: 1rem 0;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 1.5rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        nav a:hover {
            color: #ff9800;
        }
        .container {
            max-width: 500px;
            margin: 2rem auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.07);
            padding: 2rem 2.5rem;
            text-align: center;
        }
        h1 {
            margin-bottom: 0.5rem;
        }
        .thankyou-message {
            font-size: 1.2rem;
            margin-top: 1.5rem;
        }
        @media (max-width: 600px) {
            .container {
                padding: 1rem;
            }
            nav a {
                margin: 0 0.5rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Thank You!</h1>
        <nav>
            <a href="/">Home</a>
            <a href="/about">About</a>
            <a href="/projects">Projects</a>
            <a href="/resume">Resume</a>
            <a href="/contact">Contact</a>
        </nav>
    </header>
    <div class="container">
        <div class="thankyou-message">
            <p>Thank you for reaching out! Your message has been received. I appreciate your interest and will get back to you as soon as possible.<br><br>
            — Reid Zona, MSIS Student, Indiana University</p>
        </div>
    </div>
</body>
</html>
    '''

if __name__ == '__main__':
    app.run(debug=True)
